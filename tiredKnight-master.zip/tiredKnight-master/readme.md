# Tired Knight

Minimal chess AI written in python.

## Installation

- clone this repo
- create a virtual env
- install dependencies


```bash
git clone <repo URL>
cd tiredKnight
python -m venv tiredKnight
pip install -r  requirements.txt 
```
